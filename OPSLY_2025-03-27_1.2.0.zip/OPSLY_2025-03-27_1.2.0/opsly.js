
function toggleChat() {
  const box = document.getElementById("chat-box");
  box.style.display = box.style.display === "none" ? "block" : "none";
}

function sendMessage() {
  const input = document.getElementById("user-input");
  const log = document.getElementById("chat-log");
  const msg = input.value;
  if (msg.trim() === "") return;
  const reply = document.createElement("p");
  reply.textContent = "Opsly: That's a great question!";
  log.appendChild(document.createElement("p")).textContent = "You: " + msg;
  log.appendChild(reply);
  input.value = "";
}
